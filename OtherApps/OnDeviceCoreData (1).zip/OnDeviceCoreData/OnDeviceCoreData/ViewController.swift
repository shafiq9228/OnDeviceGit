//
//  ViewController.swift
//  OnDeviceCoreData
//
//  Created by MD SHAFIQ PATEL on 13/10/22.
//

import UIKit
import CoreData

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    var list = [Users]()
    
    @IBOutlet weak var id: UITextField!
    @IBOutlet weak var name: UITextField!
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var mobile: UITextField!
    
    @IBOutlet weak var tableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       
    }

    @IBAction func submitData(_ sender: Any) {
        
        AddData()
    }
    
    @IBAction func listData(_ sender: Any) {
        
        FetchData()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell1", for: indexPath)
        
        cell.textLabel?.text = "\(list[indexPath.row].name!)"
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return list.count
    }
    
    
    func FetchData(){
        
        //var users = [Users]()
        let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Users")
        
        do {
            let u1 = try context?.fetch(fetchRequest) as! [Users]
            
            list = u1.reversed()
            
            for x in u1{
                print(x.id)
            }
           
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
            
        } catch{
            print("some error")
        }
    }
    
    func AddData(){
        let idTxt = id.text
        let nametxt = name.text
        let emailtxt = email.text
        let mobiletxt = mobile.text
        
        
        let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext
        
        let user = NSEntityDescription.insertNewObject(forEntityName: "Users", into: context!) as! Users
        
        
        user.id = Int16(idTxt!) ?? 0
        user.name = nametxt!
        user.email = emailtxt!
        user.mobile = mobiletxt!
        
        do {
            
            try context?.save()
            print("succefully data added to table")
            
        } catch{
            print("Fail data adding to table")
        }
      
        
    }
    
}


//
//  Users+CoreDataClass.swift
//  OnDeviceCoreData
//
//  Created by MD SHAFIQ PATEL on 13/10/22.
//
//

import Foundation
import CoreData

@objc(Users)
public class Users: NSManagedObject {

}

//
//  ViewController.swift
//  MyNoteApp
//
//  Created by MD SHAFIQ PATEL on 17/10/22.
//

import UIKit
import CoreData

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    
    @IBOutlet weak var tableView: UITableView!
    
    
    var list = [Notes]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        
        
        
        print("View load")
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        print("appear")
        FetchData()
    }
    
    
    @IBAction func nextPage(_ sender: Any) {
        
        
    }
    
    func FetchData(){
        
        //var users = [Users]()
        let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Notes")
        
        do {
            let u1 = try context?.fetch(fetchRequest) as! [Notes]
            //list = u1.reversed()
            
            list = u1.reversed()
            
//            for x in u1{
//                print(x.title)
//            }
            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
            
           // print(list.count)
        } catch{
            print("some error")
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell1", for: indexPath)
        
        cell.textLabel?.text = "\(list[indexPath.row].title!)"
        
        cell.detailTextLabel?.text = "\(list[indexPath.row].descrpt!)"
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return list.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("\(list[indexPath.row].descrpt!)")
    }

}


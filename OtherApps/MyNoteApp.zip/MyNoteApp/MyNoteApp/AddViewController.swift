//
//  AddViewController.swift
//  MyNoteApp
//
//  Created by MD SHAFIQ PATEL on 17/10/22.
//

import UIKit
import CoreData

class AddViewController: UIViewController {

    @IBOutlet weak var desc1: UITextView!
    @IBOutlet weak var ttitleTxt: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBAction func goBack(_ sender: Any) {
        
        self.dismiss(animated: true)
        
      
    }
    
    @IBAction func saveToDB(_ sender: Any) {
        AddData()
        
    }
    
    func AddData(){
        let id = Int.random(in: 1000..<10000)
        let title = ttitleTxt.text!
        let desciption1 = desc1.text!
        
        
        let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext
        
        let user = NSEntityDescription.insertNewObject(forEntityName: "Notes", into: context!) as! Notes
        
        
        user.id = Int16(id) ?? 0
        user.title = title
        user.descrpt = desciption1
       
        
        do {
            
            try context?.save()
            print("succefully data added to table")
            
            self.dismiss(animated: true)
            
        } catch{
            print("Fail data adding to table")
        }
      
        
    }
   

}

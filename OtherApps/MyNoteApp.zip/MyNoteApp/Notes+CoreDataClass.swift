//
//  Notes+CoreDataClass.swift
//  MyNoteApp
//
//  Created by MD SHAFIQ PATEL on 17/10/22.
//
//

import Foundation
import CoreData

@objc(Notes)
public class Notes: NSManagedObject {

}

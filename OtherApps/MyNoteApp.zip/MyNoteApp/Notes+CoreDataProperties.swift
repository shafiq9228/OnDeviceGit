//
//  Notes+CoreDataProperties.swift
//  MyNoteApp
//
//  Created by MD SHAFIQ PATEL on 17/10/22.
//
//

import Foundation
import CoreData


extension Notes {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Notes> {
        return NSFetchRequest<Notes>(entityName: "Notes")
    }

    @NSManaged public var descrpt: String?
    @NSManaged public var id: Int16
    @NSManaged public var title: String?

}

extension Notes : Identifiable {

}
